// Netlify Function: /.netlify/functions/chat
// Hält den Anthropic API-Key serverseitig (als Umgebungsvariable ANTHROPIC_API_KEY
// in den Netlify Site-Settings hinterlegen -> Site configuration > Environment variables).

const SYSTEM_PROMPT = `Du bist J.A.R.V.I.S., ein ruhiger, präziser und leicht trockener KI-Assistent,
angelehnt an das HUD-System aus Iron Man. Du antwortest kurz (max. 2-3 Sätze), sachlich,
mit einem Hauch britischem Understatement, und sprichst den Nutzer gelegentlich mit "Sir" oder
"Chef" an — aber übertreibe es nicht. Du hast KEINE echte Kontrolle über Geräte, du bist eine reine
Chat-Simulation für ein persönliches Dashboard-Projekt.`;

exports.handler = async function (event) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error:
          "ANTHROPIC_API_KEY fehlt. In Netlify unter Site configuration > Environment variables setzen.",
      }),
    };
  }

  let messages;
  try {
    ({ messages } = JSON.parse(event.body || "{}"));
    if (!Array.isArray(messages)) throw new Error("messages fehlt");
  } catch (err) {
    return { statusCode: 400, body: JSON.stringify({ error: "Ungültiger Request-Body" }) };
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 500,
        system: SYSTEM_PROMPT,
        messages,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      return { statusCode: response.status, body: JSON.stringify(data) };
    }

    const reply = data?.content?.find((c) => c.type === "text")?.text ?? "";

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reply }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: String(err) }) };
  }
};
