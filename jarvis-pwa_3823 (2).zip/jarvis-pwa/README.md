# Jarvis PWA – Deployment

## 1. Auf Netlify veröffentlichen

Da die App eine **Netlify Function** (`netlify/functions/chat.js`) enthält, reicht ein einfaches
Drag & Drop des Ordners auf app.netlify.com **nicht** – dafür braucht es einen der folgenden zwei Wege:

**Option A – über GitHub (empfohlen)**
1. Diesen Ordner in ein neues GitHub-Repo pushen.
2. Auf [app.netlify.com](https://app.netlify.com) → "Add new site" → "Import an existing project" → Repo auswählen.
3. Build-Einstellungen kann Netlify automatisch aus `netlify.toml` übernehmen.

**Option B – über die Netlify CLI (ohne GitHub)**
```bash
npm install -g netlify-cli
cd jarvis-pwa
netlify deploy --prod
```

## 2. API-Key hinterlegen

In den Netlify Site-Einstellungen: **Site configuration → Environment variables** →
neue Variable `ANTHROPIC_API_KEY` mit deinem eigenen Anthropic-API-Key anlegen
(erstellst du unter [console.anthropic.com](https://console.anthropic.com)).
Danach die Seite einmal neu deployen, damit die Variable greift.

## 3. Auf dem Handy installieren

1. Die Netlify-URL (z. B. `https://dein-projekt.netlify.app`) auf dem Handy im Browser öffnen.
2. **Android (Chrome):** Menü (⋮) → "App installieren" bzw. "Zum Startbildschirm hinzufügen".
3. **iPhone (Safari):** Teilen-Button → "Zum Home-Bildschirm".

Danach startet die App wie eine normale App, ohne Browserleiste.

## Hinweise

- Die Smart-Home-Steuerung, der Orb und die Sprachein-/ausgabe funktionieren komplett lokal im Browser.
- Nur die Chat-Antworten gehen über die Netlify Function zur Anthropic API – dafür ist Internet nötig.
- Spracherkennung (Mikrofon) läuft über die Web Speech API; unter iOS/Safari ist die Unterstützung
  eingeschränkt, unter Android/Chrome funktioniert sie zuverlässig.
